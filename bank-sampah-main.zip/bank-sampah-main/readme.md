# Aplikasi Bank Sampah
Sistem informasi bank sampah berbasis web ini memiliki tampilan yang sederhana dan fitur yang menarik.

To access admin page, add url /admin. Example http://localhost/banksampah/page/login.php

## Tampilan Aplikasi
![ss](asset/ss1.png)
![ss](asset/ss2.png)
![ss](asset/ss3.png)
![ss](asset/ss4.png)
![ss](asset/ss5.png)

## Admin Account
|   Level   | Username  | Password   |
|:---------:|:---------:|-----------:|
| Admin     | admin123  | admin123   |

## Sistem Requirement
- Database MySQL
- XAMPP / PHP 5.6
